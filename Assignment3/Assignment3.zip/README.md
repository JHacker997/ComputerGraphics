
 - I used the shader code from sampleShader1.html.

 - I applied the shader material to the Ship.obj.

 - The file where all the shaders are created and applied is Assignment3.html.
   The vertex shader code starts on line 102.
   The frag shader code starts on line 120.
   The code where I use the shader code to apply to a material starts on line 56.
   The code where I apply the material is applied to an obj starts on line 80.
