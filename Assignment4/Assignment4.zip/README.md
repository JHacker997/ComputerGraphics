I could not get any kind of raw shader of my own to work.
Just submitting this to show my default Phong shader and dat GUI work.
Hopefully this is worth some points.
